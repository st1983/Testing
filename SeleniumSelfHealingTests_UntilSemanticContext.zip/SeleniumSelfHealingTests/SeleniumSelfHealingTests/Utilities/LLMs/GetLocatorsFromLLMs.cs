using System.Text.Json;
using SeleniumSelfHealingTests.Utilities.Models;

namespace SeleniumSelfHealingTests.Utilities.LLMs;

public static class GetLocatorsFromLLMs
{
    public static async Task<LocatorSuggestions?> GetHealedLocator(LLMClient client, string pageSource, string locatorType, string originalLocator, string? semanticContext=null)
    {

        var elementDescription = string.IsNullOrWhiteSpace(semanticContext)
            ? $"element with locatorType: {locatorType} and locator: {originalLocator}"
            : $"'{semanticContext}' (Original locator: {locatorType}={originalLocator})";
            
        
        var prompt = $@"
            You are helping to locate a web element that cannot be found with its original locator.

            Element you are looking for: {elementDescription}

            The original locator is no longer working. This could be because:
            - The locator value has changed (e.g., ID renamed, class modified)
            - The element structure has changed
            - The element has been moved in the DOM

            Your task: Analyze the page source below and find the element that matches the purpose described above.
            Then suggest alternative locators that would work to find this element.

            CRITICAL INSTRUCTIONS:
            1. Use the friendly name/description to understand WHAT element you're looking for
            2. Look for elements that serve the same purpose, even if IDs/classes are completely different
            3. Return ONLY a valid JSON object with these keys: id, name, xpath, cssSelector, className, linkText
            4. Each key should contain a working locator value, or an empty string if not applicable
            5. Prefer robust locators (xpath, cssSelector, id, name) over fragile ones
            6. Do not include any text before or after the JSON object
            7. Do not include explanations or comments

            Expected JSON format:
            {{
              ""id"": ""value or empty string"",
              ""name"": ""value or empty string"",
              ""xpath"": ""value or empty string"",
              ""cssSelector"": ""value or empty string"",
              ""className"": ""value or empty string"",
              ""linkText"": ""value or empty string""
            }}

            Page source (truncated): {pageSource}
            ";

        var response = await client.GetCompletionAsync(prompt);
        
        return JsonSerializer.Deserialize<LocatorSuggestions>(response) ?? null;
    }
}