using OpenQA.Selenium;

namespace SeleniumSelfHealingTests.Utilities.LLMs;

public class SelfHealingLocators
{
    private readonly IWebDriver _driver;
    private By _currentStrategy;
    private readonly Dictionary<string, By> _locatorStrategies;
    private readonly string _originalLocatorString;
    private readonly LocatorCache _cache;

    public SelfHealingLocators(IWebDriver driver, By primaryLocator)
    {
        _driver = driver;
        _currentStrategy = primaryLocator;
        _locatorStrategies = new Dictionary<string, By> { { "primary", primaryLocator } };
        _originalLocatorString = primaryLocator.ToString();
        _cache = new LocatorCache();
    }

    public async Task<IWebElement> FindElementAsync(int retryAttempts = 2, string? semanticContext=null)
    {
        //Step 1: Try finding the element using Current Strategy
        var element = TryFindWithCurrentStrategy();
        if (element != null) return element;
        
        //Step 1.5: Try get the locator from the cache
        element = TryFindWithCachedLocator();
        if (element != null) return element;
        
        //Step 2 - Find the alternative Strategy 
        element = TryAlternativeStrategies();
        if (element != null) return element;
        
        //Step 3 - AI Based AutoHealing approach
        if (retryAttempts > 0)
        {
            await HealUsingAIAsync(semanticContext);
            return await FindElementAsync(retryAttempts -1);
        }

        throw new NoSuchElementException($"Failed to locate the element after all healing attempts: {retryAttempts}");
    }


    private IWebElement? TryFindWithCurrentStrategy()
    {
        try
        {
            return _driver.FindElement(_currentStrategy);
        }
        catch (NoSuchElementException)
        {
            return null;
        }
    }

    private IWebElement? TryAlternativeStrategies()
    {
        if (_locatorStrategies.Count <= 1) return null;

        foreach (var (strategyName, strategy) in _locatorStrategies)
        {
            if(strategy.Equals(_currentStrategy)) continue;

            try
            {
                var element = _driver.FindElement(strategy);

                SaveSuccessfulLocatorToCache(strategyName, strategy);
                
                _currentStrategy = strategy; //Update to successful strategy
                return element;
            }
            catch (NoSuchElementException)
            {
                
            }
        }

        return null;
    }


    public void SaveSuccessfulLocatorToCache(string locatorType, By locatorStrategy)
    {
        var strategyString = locatorStrategy.ToString();
        int separatorIndex = strategyString.IndexOf(":");
        
        string locatorValue = strategyString.Substring(separatorIndex + 1).Trim();
        
        _cache.SaveHealedLocator(_originalLocatorString, locatorType, locatorValue);
    }

    

    private async Task HealUsingAIAsync(string? semanticContext=null)
    {
        try
        {
            var strategyString = _currentStrategy.ToString();
            int separatorIndex = strategyString.IndexOf(":");

            string locatorType = strategyString.Substring(0, separatorIndex);
            string locatorValue = strategyString.Substring(separatorIndex + 1).Trim();

            var pageSource = _driver.PageSource;

            LLMClient client = new LLMClient();
            var suggestedLocators =
                await GetLocatorsFromLLMs.GetHealedLocator(client, pageSource, locatorType, locatorValue,semanticContext);

            int addedCount = 0;
            addedCount += TryCreateLocatorStrategy("id", suggestedLocators.id);
            addedCount += TryCreateLocatorStrategy("xpath", suggestedLocators.xpath);
            addedCount += TryCreateLocatorStrategy("css", suggestedLocators.cssSelector);
            addedCount += TryCreateLocatorStrategy("name", suggestedLocators.name);
            addedCount += TryCreateLocatorStrategy("class", suggestedLocators.className);
            addedCount += TryCreateLocatorStrategy("linkText", suggestedLocators.linkText);

            Console.WriteLine(
                $"AI healing completed with total added locators are {addedCount} as alternative locators");
        }
        catch (Exception ex)
        {
            Console.WriteLine("AI healing failed");
        }
    }


    private int TryCreateLocatorStrategy(string locatorType, string locatorValue)
    {
        var by = CreateByFromTypeAndValue(locatorType, locatorValue);
        
        if (by == null)
            return 0;
            
        _locatorStrategies[locatorType] = by;
            return 1;
    }

    private IWebElement? TryFindWithCachedLocator()
    {
        if (_cache.TryGetHealedLocator(_originalLocatorString, out var healedLocator) && healedLocator != null)
        {
            try
            {
                var by = CreateByFromTypeAndValue(healedLocator.WorkingLocatorType, healedLocator.WorkingLocatorValue);
                if (by != null)
                {
                    var element = _driver.FindElement(by);
                    _currentStrategy = by;
                    return element;
                }
            }
            catch (NoSuchElementException ex)
            {
                Console.WriteLine("Cached Healed locator No longer works !");
            }
        }

        return null;
    }
    
    private By? CreateByFromTypeAndValue(string locatorType, string locatorValue)
    {
        if (string.IsNullOrWhiteSpace(locatorValue))
            return null;

        try
        {
            return locatorType.ToLowerInvariant() switch
            {
                "id" => By.Id(locatorValue),
                "name" => By.Name(locatorValue),
                "classname" or "class" => By.ClassName(locatorValue),
                "tagname" or "tag" => By.TagName(locatorValue),
                "linktext" => By.LinkText(locatorValue),
                "partiallinktext" => By.PartialLinkText(locatorValue),
                "cssselector" or "css" => By.CssSelector(locatorValue),
                "xpath" => By.XPath(locatorValue),
                _ => null
            };
        }
        catch
        {
            return null;
        }
    }
    
}