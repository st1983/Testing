using OpenQA.Selenium;
using SeleniumSelfHealingTests.Utilities.Extensions;

namespace SeleniumSelfHealingTests.Pages;

public class LoginPage
{
    public LoginPage(IWebDriver driver)
    {
        _driver = driver;
    }
    
    private readonly IWebDriver _driver; 
    private Task<IWebElement> UsernameField => _driver.AiFindElement(By.Id("NextText"), "for User Name field");
    private Task<IWebElement> PasswordField => _driver.AiFindElement(By.Id("NewTEXT"), "for password field");
    private Task<IWebElement> LoginButton => _driver.AiFindElement(By.CssSelector("input[type='SOMETGHING']"), "login button field");
    
    public async Task Login(string userName, string password)
    {
       await UsernameField.SendKeys(userName);
       await PasswordField.SendKeys(password);
       await LoginButton.Click();
    }
  
}
