using AventStack.ExtentReports;
using AventStack.ExtentReports.Reporter;
using NUnit.Framework;
using NUnit.Framework.Interfaces;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using WebDriverManager;
using WebDriverManager.DriverConfigs.Impl;

namespace ZywaveLoginAutomation.Common
{
    /// <summary>
    /// Base class for all UI tests.
    /// Manages WebDriver lifecycle and ExtentReports.
    /// </summary>
    public class BaseTest
    {
        protected IWebDriver Driver = null!;
        protected ExtentReports Extent = null!;
        protected ExtentTest Test = null!;

        private static readonly string ReportPath =
            Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Reports", "TestReport.html");

        [OneTimeSetUp]
        public void GlobalSetup()
        {
            Directory.CreateDirectory(Path.GetDirectoryName(ReportPath)!);
            var htmlReporter = new ExtentHtmlReporter(ReportPath);
            htmlReporter.Config.Theme = AventStack.ExtentReports.Reporter.Configuration.Theme.Dark;
            htmlReporter.Config.DocumentTitle = "Zywave Login Automation Report";
            htmlReporter.Config.ReportName = "UI + API Test Results";

            Extent = new ExtentReports();
            Extent.AttachReporter(htmlReporter);
            Extent.AddSystemInfo("Environment", "Local");
            Extent.AddSystemInfo("Base URL", TestData.Urls.BaseUrl);
            Extent.AddSystemInfo("Browser", "Chrome (Headless)");
        }

        [SetUp]
        public void Setup()
        {
            // Auto-download ChromeDriver matching installed Chrome
            new DriverManager().SetUpDriver(new ChromeConfig());

            var options = new ChromeOptions();
            options.AddArgument("--headless");
            options.AddArgument("--no-sandbox");
            options.AddArgument("--disable-dev-shm-usage");
            options.AddArgument("--window-size=1920,1080");

            Driver = new ChromeDriver(options);
            Driver.Manage().Timeouts().ImplicitWait =
                TimeSpan.FromSeconds(TestData.Timeouts.DefaultWaitSeconds);
            Driver.Manage().Timeouts().PageLoad =
                TimeSpan.FromSeconds(TestData.Timeouts.PageLoadSeconds);

            Test = Extent.CreateTest(TestContext.CurrentContext.Test.Name);
        }

        [TearDown]
        public void TearDown()
        {
            var status = TestContext.CurrentContext.Result.Outcome.Status;
            var message = TestContext.CurrentContext.Result.Message ?? string.Empty;

            switch (status)
            {
                case TestStatus.Failed:
                    var screenshot = TakeScreenshot();
                    Test.Fail(message, MediaEntityBuilder
                        .CreateScreenCaptureFromBase64String(screenshot).Build());
                    break;
                case TestStatus.Skipped:
                    Test.Skip("Test skipped");
                    break;
                default:
                    Test.Pass("Test passed");
                    break;
            }

            Driver?.Quit();
        }

        [OneTimeTearDown]
        public void GlobalTearDown()
        {
            Extent.Flush();
            TestContext.WriteLine($"Report generated at: {ReportPath}");
        }

        private string TakeScreenshot()
        {
            var ss = ((ITakesScreenshot)Driver).GetScreenshot();
            return ss.AsBase64EncodedString;
        }
    }
}
