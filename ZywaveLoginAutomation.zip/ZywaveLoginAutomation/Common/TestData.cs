namespace ZywaveLoginAutomation.Common
{
    /// <summary>
    /// Centralized test data. Replace with real credentials if provided by Zywave.
    /// </summary>
    public static class TestData
    {
        // ── Credentials ──────────────────────────────────────────────────────────
        public static class Users
        {
            public static readonly (string Email, string Password) ValidUser =
                ("testuser@zywave.com", "Test@1234");

            public static readonly (string Email, string Password) LockedUser =
                ("locked@zywave.com", "Test@1234");

            public static readonly (string Email, string Password) ExpiredPasswordUser =
                ("expired@zywave.com", "OldPass@99");

            public static readonly (string Email, string Password) WrongPassword =
                ("testuser@zywave.com", "WrongPass!");

            public static readonly (string Email, string Password) WrongEmail =
                ("nouser@zywave.com", "Test@1234");

            public static readonly (string Email, string Password) EmptyCredentials =
                ("", "");

            public static readonly (string Email, string Password) EmptyPassword =
                ("testuser@zywave.com", "");

            public static readonly (string Email, string Password) EmptyEmail =
                ("", "Test@1234");

            public static readonly (string Email, string Password) InvalidEmailFormat =
                ("notanemail", "Test@1234");

            public static readonly (string Email, string Password) SqlInjection =
                ("' OR '1'='1", "' OR '1'='1");
        }

        // ── App URLs ──────────────────────────────────────────────────────────────
        public static class Urls
        {
            public const string BaseUrl    = "http://localhost:5000";
            public const string LoginPage  = BaseUrl + "/login";
            public const string SwaggerUrl = BaseUrl + "/swagger";

            // API endpoints
            public const string ApiBase    = BaseUrl + "/api";
            public const string LoginApi   = ApiBase + "/auth/login";
            public const string TokenApi   = ApiBase + "/auth/token";
            public const string RefreshApi = ApiBase + "/auth/refresh";
            public const string LogoutApi  = ApiBase + "/auth/logout";
            public const string UserInfoApi= ApiBase + "/auth/userinfo";
        }

        // ── Timeouts ─────────────────────────────────────────────────────────────
        public static class Timeouts
        {
            public const int DefaultWaitSeconds  = 10;
            public const int PageLoadSeconds     = 20;
            public const int ApiTimeoutSeconds   = 30;
        }

        // ── Expected Messages ─────────────────────────────────────────────────────
        public static class Messages
        {
            public const string InvalidCredentials  = "Invalid username or password";
            public const string AccountLocked       = "Account is locked";
            public const string RequiredField       = "This field is required";
            public const string InvalidEmailFormat  = "Please enter a valid email address";
            public const string PasswordExpired     = "Your password has expired";
        }
    }
}
