using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.WaitHelpers;
using ZywaveLoginAutomation.Common;

namespace ZywaveLoginAutomation.Common
{
    /// <summary>
    /// Fluent explicit-wait helpers — mirrors what you'd use in Java with FluentWait.
    /// </summary>
    public static class WaitHelper
    {
        public static IWebElement WaitForVisible(IWebDriver driver, By locator, int seconds = 0)
        {
            seconds = seconds == 0 ? TestData.Timeouts.DefaultWaitSeconds : seconds;
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(seconds));
            return wait.Until(ExpectedConditions.ElementIsVisible(locator));
        }

        public static IWebElement WaitForClickable(IWebDriver driver, By locator, int seconds = 0)
        {
            seconds = seconds == 0 ? TestData.Timeouts.DefaultWaitSeconds : seconds;
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(seconds));
            return wait.Until(ExpectedConditions.ElementToBeClickable(locator));
        }

        public static bool WaitForText(IWebDriver driver, By locator, string text, int seconds = 0)
        {
            seconds = seconds == 0 ? TestData.Timeouts.DefaultWaitSeconds : seconds;
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(seconds));
            return wait.Until(ExpectedConditions.TextToBePresentInElementLocated(locator, text));
        }

        public static bool WaitForUrlContains(IWebDriver driver, string partial, int seconds = 0)
        {
            seconds = seconds == 0 ? TestData.Timeouts.DefaultWaitSeconds : seconds;
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(seconds));
            return wait.Until(ExpectedConditions.UrlContains(partial));
        }

        public static bool IsElementPresent(IWebDriver driver, By locator)
        {
            try
            {
                driver.FindElement(locator);
                return true;
            }
            catch (NoSuchElementException)
            {
                return false;
            }
        }
    }
}
