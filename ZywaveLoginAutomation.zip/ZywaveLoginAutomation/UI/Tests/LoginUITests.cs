using NUnit.Framework;
using ZywaveLoginAutomation.Common;
using ZywaveLoginAutomation.UI.Pages;

namespace ZywaveLoginAutomation.UI.Tests
{
    /// <summary>
    /// UI test suite for the Login screen.
    /// Covers: happy path, field validation, error messages, security, UI behaviour.
    ///
    /// Equivalent to your Java/TestNG experience — NUnit [Test] = @Test, 
    /// [SetUp]/[TearDown] = @BeforeMethod/@AfterMethod
    /// </summary>
    [TestFixture]
    [Category("UI")]
    public class LoginUITests : BaseTest
    {
        private LoginPage _loginPage = null!;

        [SetUp]
        public new void Setup()
        {
            base.Setup();
            _loginPage = new LoginPage(Driver);
            _loginPage.Navigate();
        }

        // ── Happy Path ────────────────────────────────────────────────────────────

        [Test]
        [Description("Valid credentials should redirect user away from login page")]
        public void TC_UI_001_ValidLogin_ShouldRedirectToDashboard()
        {
            var (email, password) = TestData.Users.ValidUser;

            _loginPage.LoginWith(email, password);

            Assert.That(_loginPage.IsRedirectedAfterLogin(), Is.True,
                "Expected redirect after successful login but URL still contains /login");
        }

        // ── Field Validation ─────────────────────────────────────────────────────

        [Test]
        [Description("Empty email and password should show required field errors")]
        public void TC_UI_002_EmptyFields_ShouldShowRequiredErrors()
        {
            _loginPage.ClickLogin();

            Assert.That(_loginPage.IsErrorDisplayed() ||
                        WaitHelper.IsElementPresent(Driver,
                            OpenQA.Selenium.By.CssSelector(".email-error, #email-error")),
                Is.True, "Expected validation error for empty fields");
        }

        [Test]
        [Description("Empty password only should show password required error")]
        public void TC_UI_003_EmptyPasswordOnly_ShouldShowPasswordError()
        {
            var (email, _) = TestData.Users.EmptyPassword;

            _loginPage.EnterEmail(email).ClickLogin();

            Assert.That(_loginPage.IsErrorDisplayed(), Is.True,
                "Expected error when password is empty");
        }

        [Test]
        [Description("Empty email only should show email required error")]
        public void TC_UI_004_EmptyEmailOnly_ShouldShowEmailError()
        {
            _loginPage.EnterPassword("SomePass@1").ClickLogin();

            Assert.That(_loginPage.IsErrorDisplayed(), Is.True,
                "Expected error when email is empty");
        }

        [Test]
        [Description("Malformed email format should show format validation error")]
        public void TC_UI_005_InvalidEmailFormat_ShouldShowFormatError()
        {
            var (email, password) = TestData.Users.InvalidEmailFormat;

            _loginPage.LoginWith(email, password);

            Assert.That(_loginPage.IsErrorDisplayed(), Is.True,
                "Expected email format validation error");
        }

        // ── Error Messages ────────────────────────────────────────────────────────

        [Test]
        [Description("Wrong password should show invalid credentials message")]
        public void TC_UI_006_WrongPassword_ShouldShowInvalidCredentialsError()
        {
            var (email, password) = TestData.Users.WrongPassword;

            _loginPage.LoginWith(email, password);

            var error = _loginPage.GetErrorMessage();
            Assert.That(error, Does.Contain("Invalid").Or.Contain("incorrect").Or.Contain("wrong")
                .IgnoreCase, $"Unexpected error message: {error}");
        }

        [Test]
        [Description("Non-existent user should show generic invalid credentials (no user enumeration)")]
        public void TC_UI_007_WrongEmail_ShouldShowGenericError()
        {
            var (email, password) = TestData.Users.WrongEmail;

            _loginPage.LoginWith(email, password);

            var error = _loginPage.GetErrorMessage();
            // Security: message must NOT reveal whether the email exists
            Assert.That(error, Does.Not.Contain("not registered").IgnoreCase,
                "User enumeration vulnerability: error reveals email existence");
            Assert.That(error.Length, Is.GreaterThan(0), "Expected an error message");
        }

        [Test]
        [Description("Locked account should show account locked message")]
        [Category("NegativeScenarios")]
        public void TC_UI_008_LockedAccount_ShouldShowLockedMessage()
        {
            var (email, password) = TestData.Users.LockedUser;

            _loginPage.LoginWith(email, password);

            var error = _loginPage.GetErrorMessage();
            Assert.That(error, Does.Contain("locked").Or.Contain("disabled").Or.Contain("suspended")
                .IgnoreCase, $"Expected account locked message but got: {error}");
        }

        // ── Password Masking / Toggle ─────────────────────────────────────────────

        [Test]
        [Description("Password field should be masked (type=password) by default")]
        public void TC_UI_009_PasswordField_ShouldBeMaskedByDefault()
        {
            _loginPage.EnterPassword("TestPassword");
            var fieldType = _loginPage.GetPasswordFieldType();

            Assert.That(fieldType, Is.EqualTo("password"),
                "Password field should be masked (type='password') by default");
        }

        [Test]
        [Description("Clicking show-password toggle should reveal password text")]
        public void TC_UI_010_PasswordToggle_ShouldRevealPassword()
        {
            _loginPage.EnterPassword("TestPassword");

            // Toggle to show
            _loginPage.ClickPasswordToggle();
            var typeAfterToggle = _loginPage.GetPasswordFieldType();

            Assert.That(typeAfterToggle, Is.EqualTo("text"),
                "After clicking toggle, password field should change to type='text'");
        }

        [Test]
        [Description("Clicking toggle twice should re-mask the password")]
        public void TC_UI_011_PasswordToggle_ShouldMaskAgainOnSecondClick()
        {
            _loginPage.EnterPassword("TestPassword");
            _loginPage.ClickPasswordToggle(); // show
            _loginPage.ClickPasswordToggle(); // hide again

            var finalType = _loginPage.GetPasswordFieldType();
            Assert.That(finalType, Is.EqualTo("password"),
                "After toggling twice, password should be masked again");
        }

        // ── Security ──────────────────────────────────────────────────────────────

        [Test]
        [Description("SQL injection in credentials should not bypass authentication")]
        [Category("Security")]
        public void TC_UI_012_SqlInjection_ShouldNotBypassLogin()
        {
            var (email, password) = TestData.Users.SqlInjection;

            _loginPage.LoginWith(email, password);

            // Must NOT be redirected to dashboard
            Assert.That(_loginPage.IsOnLoginPage(), Is.True,
                "SQL injection should not bypass authentication");
        }

        [Test]
        [Description("Page should load over HTTP with no mixed content issues")]
        [Category("Security")]
        public void TC_UI_013_LoginPage_ShouldLoadCorrectly()
        {
            var title = _loginPage.GetPageTitle();
            var url   = _loginPage.GetCurrentUrl();

            Assert.That(url, Does.Contain("localhost:5000"),
                "Should be on the correct host");
            Assert.That(title, Is.Not.Empty,
                "Page should have a visible title or heading");
        }

        // ── Page Elements ─────────────────────────────────────────────────────────

        [Test]
        [Description("Forgot Password link should be present on login page")]
        public void TC_UI_014_ForgotPasswordLink_ShouldBePresent()
        {
            Assert.That(
                WaitHelper.IsElementPresent(Driver,
                    OpenQA.Selenium.By.CssSelector("a[href*='forgot'], a.forgot-password")),
                Is.True,
                "Forgot Password link should be visible on login page");
        }

        [Test]
        [Description("Login button should be enabled on page load")]
        public void TC_UI_015_LoginButton_ShouldBeEnabledByDefault()
        {
            Assert.That(_loginPage.IsLoginButtonEnabled(), Is.True,
                "Login button should be enabled by default");
        }

        // ── Negative / Edge Cases ────────────────────────────────────────────────

        [Test]
        [Description("Very long input strings should be handled gracefully")]
        [Category("NegativeScenarios")]
        public void TC_UI_016_OverlongInput_ShouldNotCrashApp()
        {
            var longString = new string('A', 500);

            Assert.DoesNotThrow(() =>
            {
                _loginPage.LoginWith(longString + "@test.com", longString);
            }, "App should handle overly long input without throwing");

            // Should still be on login or show an error — not crash
            Assert.That(_loginPage.IsOnLoginPage() || _loginPage.IsErrorDisplayed(),
                Is.True, "Should remain on login page or show error for long input");
        }

        [Test]
        [Description("Expired password user should see password-change prompt or specific error")]
        [Category("NegativeScenarios")]
        public void TC_UI_017_ExpiredPassword_ShouldShowExpiredMessage()
        {
            var (email, password) = TestData.Users.ExpiredPasswordUser;

            _loginPage.LoginWith(email, password);

            Assert.That(_loginPage.IsErrorDisplayed(), Is.True,
                "Expected an error or redirect for expired password user");
        }
    }
}
