using OpenQA.Selenium;
using ZywaveLoginAutomation.Common;

namespace ZywaveLoginAutomation.UI.Pages
{
    /// <summary>
    /// Page Object for the Login screen at http://localhost:5000/login
    ///
    /// Locators use CSS selectors as primary strategy.
    /// Update selectors once you inspect the actual app DOM.
    /// </summary>
    public class LoginPage
    {
        private readonly IWebDriver _driver;

        // ── Locators ──────────────────────────────────────────────────────────────
        private readonly By _emailField       = By.CssSelector("input[type='email'], input[name='email'], input[id='email']");
        private readonly By _passwordField    = By.CssSelector("input[type='password'], input[name='password'], input[id='password']");
        private readonly By _loginButton      = By.CssSelector("button[type='submit'], button.login-btn, input[type='submit']");
        private readonly By _errorMessage     = By.CssSelector(".error-message, .alert-danger, [data-testid='error-msg'], .login-error");
        private readonly By _emailError       = By.CssSelector(".email-error, [data-testid='email-error'], #email-error");
        private readonly By _passwordError    = By.CssSelector(".password-error, [data-testid='password-error'], #password-error");
        private readonly By _passwordToggleBtn= By.CssSelector("button.toggle-password, [data-testid='show-password'], .eye-icon");
        private readonly By _forgotPasswordLink= By.CssSelector("a[href*='forgot'], a.forgot-password");
        private readonly By _rememberMeCheckbox= By.CssSelector("input[type='checkbox'][name='remember'], #rememberMe");
        private readonly By _pageTitle        = By.CssSelector("h1, h2.login-title, .login-header");

        public LoginPage(IWebDriver driver)
        {
            _driver = driver;
        }

        // ── Navigation ────────────────────────────────────────────────────────────
        public LoginPage Navigate()
        {
            _driver.Navigate().GoToUrl(TestData.Urls.LoginPage);
            WaitHelper.WaitForVisible(_driver, _emailField);
            return this;
        }

        // ── Actions ───────────────────────────────────────────────────────────────
        public LoginPage EnterEmail(string email)
        {
            var field = WaitHelper.WaitForVisible(_driver, _emailField);
            field.Clear();
            field.SendKeys(email);
            return this;
        }

        public LoginPage EnterPassword(string password)
        {
            var field = WaitHelper.WaitForVisible(_driver, _passwordField);
            field.Clear();
            field.SendKeys(password);
            return this;
        }

        public LoginPage ClickLogin()
        {
            WaitHelper.WaitForClickable(_driver, _loginButton).Click();
            return this;
        }

        public LoginPage ClickPasswordToggle()
        {
            WaitHelper.WaitForClickable(_driver, _passwordToggleBtn).Click();
            return this;
        }

        public LoginPage ClickForgotPassword()
        {
            WaitHelper.WaitForClickable(_driver, _forgotPasswordLink).Click();
            return this;
        }

        public LoginPage ClickRememberMe()
        {
            WaitHelper.WaitForClickable(_driver, _rememberMeCheckbox).Click();
            return this;
        }

        /// <summary>Convenience: fill both fields and submit.</summary>
        public LoginPage LoginWith(string email, string password)
        {
            return EnterEmail(email)
                  .EnterPassword(password)
                  .ClickLogin();
        }

        // ── Assertions / Getters ──────────────────────────────────────────────────
        public string GetErrorMessage()
        {
            var el = WaitHelper.WaitForVisible(_driver, _errorMessage);
            return el.Text.Trim();
        }

        public string GetEmailValidationError()
        {
            var el = WaitHelper.WaitForVisible(_driver, _emailError);
            return el.Text.Trim();
        }

        public string GetPasswordValidationError()
        {
            var el = WaitHelper.WaitForVisible(_driver, _passwordError);
            return el.Text.Trim();
        }

        public string GetPasswordFieldType()
        {
            return _driver.FindElement(_passwordField).GetAttribute("type");
        }

        public bool IsLoginButtonEnabled()
        {
            return _driver.FindElement(_loginButton).Enabled;
        }

        public bool IsErrorDisplayed()
        {
            return WaitHelper.IsElementPresent(_driver, _errorMessage);
        }

        public bool IsOnLoginPage()
        {
            return _driver.Url.Contains("login") || _driver.Url == TestData.Urls.BaseUrl + "/";
        }

        public bool IsRedirectedAfterLogin()
        {
            // Successful login should navigate away from /login
            return WaitHelper.WaitForUrlContains(_driver, "dashboard")
                || !_driver.Url.Contains("login");
        }

        public string GetCurrentUrl() => _driver.Url;

        public string GetPageTitle()
        {
            try { return _driver.FindElement(_pageTitle).Text.Trim(); }
            catch { return _driver.Title; }
        }
    }
}
