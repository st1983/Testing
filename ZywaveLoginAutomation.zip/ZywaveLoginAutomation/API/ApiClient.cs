using Newtonsoft.Json;
using RestSharp;
using ZywaveLoginAutomation.Common;

namespace ZywaveLoginAutomation.API
{
    /// <summary>
    /// RestSharp client wrapper.
    /// Mirrors how you'd use RequestSpecification + RestAssured in Java.
    ///
    /// Usage:
    ///   var client = new ApiClient();
    ///   var response = client.Post("/api/auth/login", new LoginRequest { ... });
    /// </summary>
    public class ApiClient : IDisposable
    {
        private readonly RestClient _client;

        public ApiClient(string? bearerToken = null)
        {
            var options = new RestClientOptions(TestData.Urls.BaseUrl)
            {
                ThrowOnAnyError = false,
                MaxTimeout = TestData.Timeouts.ApiTimeoutSeconds * 1000
            };

            _client = new RestClient(options);
            _client.AddDefaultHeader("Accept", "application/json");
            _client.AddDefaultHeader("Content-Type", "application/json");

            if (!string.IsNullOrEmpty(bearerToken))
                _client.AddDefaultHeader("Authorization", $"Bearer {bearerToken}");
        }

        // ── Generic Execute ───────────────────────────────────────────────────────

        public RestResponse<T> Execute<T>(RestRequest request) where T : new()
        {
            return _client.Execute<T>(request);
        }

        public RestResponse Execute(RestRequest request)
        {
            return _client.Execute(request);
        }

        // ── Convenience Methods ───────────────────────────────────────────────────

        public RestResponse<T> Post<T>(string endpoint, object body) where T : new()
        {
            var request = new RestRequest(endpoint, Method.Post);
            request.AddJsonBody(body);
            return _client.Execute<T>(request);
        }

        public RestResponse Post(string endpoint, object body)
        {
            var request = new RestRequest(endpoint, Method.Post);
            request.AddJsonBody(body);
            return _client.Execute(request);
        }

        public RestResponse<T> Get<T>(string endpoint) where T : new()
        {
            var request = new RestRequest(endpoint, Method.Get);
            return _client.Execute<T>(request);
        }

        public RestResponse Get(string endpoint)
        {
            var request = new RestRequest(endpoint, Method.Get);
            return _client.Execute(request);
        }

        // ── JSON Helpers ──────────────────────────────────────────────────────────

        public static T? Deserialize<T>(string json)
        {
            return JsonConvert.DeserializeObject<T>(json);
        }

        public static bool IsValidJson(string json)
        {
            try
            {
                JsonConvert.DeserializeObject(json);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public void Dispose() => _client.Dispose();
    }
}
