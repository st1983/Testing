using Newtonsoft.Json;

namespace ZywaveLoginAutomation.API.Models
{
    // ── Request Models ────────────────────────────────────────────────────────────

    public class LoginRequest
    {
        [JsonProperty("email")]
        public string Email { get; set; } = string.Empty;

        [JsonProperty("password")]
        public string Password { get; set; } = string.Empty;
    }

    public class RefreshRequest
    {
        [JsonProperty("refreshToken")]
        public string RefreshToken { get; set; } = string.Empty;
    }

    public class LogoutRequest
    {
        [JsonProperty("refreshToken")]
        public string RefreshToken { get; set; } = string.Empty;
    }

    // ── Response Models ───────────────────────────────────────────────────────────

    public class LoginResponse
    {
        [JsonProperty("accessToken")]
        public string? AccessToken { get; set; }

        [JsonProperty("refreshToken")]
        public string? RefreshToken { get; set; }

        [JsonProperty("tokenType")]
        public string? TokenType { get; set; }

        [JsonProperty("expiresIn")]
        public int ExpiresIn { get; set; }
    }

    public class ErrorResponse
    {
        [JsonProperty("message")]
        public string? Message { get; set; }

        [JsonProperty("error")]
        public string? Error { get; set; }

        [JsonProperty("statusCode")]
        public int StatusCode { get; set; }
    }

    public class UserInfoResponse
    {
        [JsonProperty("id")]
        public string? Id { get; set; }

        [JsonProperty("email")]
        public string? Email { get; set; }

        [JsonProperty("name")]
        public string? Name { get; set; }

        [JsonProperty("roles")]
        public List<string>? Roles { get; set; }
    }

    public class TokenResponse
    {
        [JsonProperty("accessToken")]
        public string? AccessToken { get; set; }

        [JsonProperty("refreshToken")]
        public string? RefreshToken { get; set; }

        [JsonProperty("tokenType")]
        public string? TokenType { get; set; }
    }
}
