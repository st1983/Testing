using System.Net;
using AventStack.ExtentReports;
using AventStack.ExtentReports.Reporter;
using Newtonsoft.Json;
using NUnit.Framework;
using NUnit.Framework.Interfaces;
using RestSharp;
using ZywaveLoginAutomation.API.Models;
using ZywaveLoginAutomation.Common;

namespace ZywaveLoginAutomation.API.Tests
{
    /// <summary>
    /// API test suite for authentication endpoints.
    /// Targets: /api/auth/login, /auth/token, /auth/refresh, /auth/logout, /auth/userinfo
    ///
    /// Equivalent to your REST Assured + TestNG tests in Java.
    /// </summary>
    [TestFixture]
    [Category("API")]
    public class AuthApiTests
    {
        private ApiClient _client = null!;
        private string? _validAccessToken;
        private string? _validRefreshToken;

        private ExtentReports _extent = null!;
        private ExtentTest _test = null!;

        private static readonly string ReportPath =
            Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Reports", "ApiTestReport.html");

        [OneTimeSetUp]
        public void GlobalSetup()
        {
            Directory.CreateDirectory(Path.GetDirectoryName(ReportPath)!);
            var htmlReporter = new ExtentHtmlReporter(ReportPath);
            htmlReporter.Config.Theme = AventStack.ExtentReports.Reporter.Configuration.Theme.Dark;
            _extent = new ExtentReports();
            _extent.AttachReporter(htmlReporter);
            _extent.AddSystemInfo("Base URL", TestData.Urls.BaseUrl);
            _extent.AddSystemInfo("Swagger", TestData.Urls.SwaggerUrl);

            // Pre-login to obtain tokens used in auth-required tests
            using var setupClient = new ApiClient();
            var loginResp = setupClient.Post<LoginResponse>(
                TestData.Urls.LoginApi,
                new LoginRequest
                {
                    Email    = TestData.Users.ValidUser.Email,
                    Password = TestData.Users.ValidUser.Password
                });

            if (loginResp.StatusCode == HttpStatusCode.OK && loginResp.Data != null)
            {
                _validAccessToken  = loginResp.Data.AccessToken;
                _validRefreshToken = loginResp.Data.RefreshToken;
                TestContext.WriteLine($"[Setup] Pre-login succeeded. Token: {_validAccessToken?[..20]}...");
            }
            else
            {
                TestContext.WriteLine($"[Setup WARNING] Pre-login failed ({loginResp.StatusCode}). " +
                                     "Auth-required tests may fail.");
            }
        }

        [SetUp]
        public void Setup()
        {
            _client = new ApiClient();
            _test   = _extent.CreateTest(TestContext.CurrentContext.Test.Name);
        }

        [TearDown]
        public void TearDown()
        {
            _client.Dispose();
            var status = TestContext.CurrentContext.Result.Outcome.Status;
            if (status == TestStatus.Failed)
                _test.Fail(TestContext.CurrentContext.Result.Message);
            else if (status == TestStatus.Skipped)
                _test.Skip("Skipped");
            else
                _test.Pass("Passed");
        }

        [OneTimeTearDown]
        public void GlobalTearDown() => _extent.Flush();

        // =========================================================================
        // POST /api/auth/login
        // =========================================================================

        [Test]
        [Description("Valid credentials should return 200 with accessToken and refreshToken")]
        public void TC_API_001_Login_ValidCredentials_Returns200WithTokens()
        {
            var response = _client.Post<LoginResponse>(
                TestData.Urls.LoginApi,
                new LoginRequest
                {
                    Email    = TestData.Users.ValidUser.Email,
                    Password = TestData.Users.ValidUser.Password
                });

            Assert.That((int)response.StatusCode, Is.EqualTo(200),
                $"Expected 200, got {(int)response.StatusCode}. Body: {response.Content}");

            var data = response.Data;
            Assert.That(data, Is.Not.Null, "Response body should deserialize to LoginResponse");
            Assert.That(data!.AccessToken,  Is.Not.Null.And.Not.Empty, "accessToken should be present");
            Assert.That(data.RefreshToken,  Is.Not.Null.And.Not.Empty, "refreshToken should be present");
            Assert.That(data.TokenType,     Does.Contain("Bearer").IgnoreCase, "tokenType should be Bearer");
            Assert.That(data.ExpiresIn,     Is.GreaterThan(0), "expiresIn should be positive");
        }

        [Test]
        [Description("Login response body should be valid JSON")]
        public void TC_API_002_Login_ValidCredentials_ResponseIsValidJson()
        {
            var response = _client.Post(
                TestData.Urls.LoginApi,
                new LoginRequest
                {
                    Email    = TestData.Users.ValidUser.Email,
                    Password = TestData.Users.ValidUser.Password
                });

            Assert.That(ApiClient.IsValidJson(response.Content ?? ""), Is.True,
                "Response body should be valid JSON");
        }

        [Test]
        [Description("Wrong password should return 401 Unauthorized")]
        public void TC_API_003_Login_WrongPassword_Returns401()
        {
            var response = _client.Post(
                TestData.Urls.LoginApi,
                new LoginRequest
                {
                    Email    = TestData.Users.WrongPassword.Email,
                    Password = TestData.Users.WrongPassword.Password
                });

            Assert.That((int)response.StatusCode, Is.EqualTo(401),
                $"Expected 401, got {(int)response.StatusCode}");
        }

        [Test]
        [Description("Non-existent email should return 401 (not 404 — prevent user enumeration)")]
        public void TC_API_004_Login_NonExistentEmail_Returns401NotUserEnumeration()
        {
            var response = _client.Post(
                TestData.Urls.LoginApi,
                new LoginRequest
                {
                    Email    = TestData.Users.WrongEmail.Email,
                    Password = TestData.Users.WrongEmail.Password
                });

            // Must NOT return 404 (would reveal that email doesn't exist)
            Assert.That((int)response.StatusCode, Is.EqualTo(401),
                "Non-existent user should return 401, not 404 (avoid user enumeration)");
        }

        [Test]
        [Description("Empty email and password should return 400 Bad Request")]
        public void TC_API_005_Login_EmptyCredentials_Returns400()
        {
            var response = _client.Post(
                TestData.Urls.LoginApi,
                new LoginRequest { Email = "", Password = "" });

            Assert.That((int)response.StatusCode,
                Is.EqualTo(400).Or.EqualTo(422),
                $"Expected 400 or 422 for empty credentials, got {(int)response.StatusCode}");
        }

        [Test]
        [Description("Malformed JSON body should return 400")]
        public void TC_API_006_Login_MalformedJson_Returns400()
        {
            var request = new RestRequest(TestData.Urls.LoginApi, Method.Post);
            request.AddStringBody("{ invalid json }", "application/json");
            var response = _client.Execute(request);

            Assert.That((int)response.StatusCode, Is.EqualTo(400),
                "Malformed JSON should return 400");
        }

        [Test]
        [Description("Locked account should return 401 or 423")]
        [Category("NegativeScenarios")]
        public void TC_API_007_Login_LockedAccount_Returns401Or423()
        {
            var response = _client.Post(
                TestData.Urls.LoginApi,
                new LoginRequest
                {
                    Email    = TestData.Users.LockedUser.Email,
                    Password = TestData.Users.LockedUser.Password
                });

            Assert.That((int)response.StatusCode,
                Is.EqualTo(401).Or.EqualTo(423),
                $"Locked account should return 401 or 423, got {(int)response.StatusCode}");
        }

        [Test]
        [Description("SQL injection payload should not return 200")]
        [Category("Security")]
        public void TC_API_008_Login_SqlInjection_ShouldNotReturn200()
        {
            var response = _client.Post(
                TestData.Urls.LoginApi,
                new LoginRequest
                {
                    Email    = TestData.Users.SqlInjection.Email,
                    Password = TestData.Users.SqlInjection.Password
                });

            Assert.That((int)response.StatusCode, Is.Not.EqualTo(200),
                "SQL injection should never return 200 OK");
        }

        // =========================================================================
        // POST /api/auth/refresh
        // =========================================================================

        [Test]
        [Description("Valid refresh token should return new access token with 200")]
        public void TC_API_009_Refresh_ValidToken_Returns200WithNewAccessToken()
        {
            if (string.IsNullOrEmpty(_validRefreshToken))
                Assert.Ignore("Skipped: no valid refresh token from pre-login setup");

            var response = _client.Post<TokenResponse>(
                TestData.Urls.RefreshApi,
                new RefreshRequest { RefreshToken = _validRefreshToken! });

            Assert.That((int)response.StatusCode, Is.EqualTo(200),
                $"Expected 200, got {(int)response.StatusCode}. Body: {response.Content}");
            Assert.That(response.Data?.AccessToken, Is.Not.Null.And.Not.Empty,
                "Refresh should return a new accessToken");
        }

        [Test]
        [Description("Invalid/expired refresh token should return 401")]
        public void TC_API_010_Refresh_InvalidToken_Returns401()
        {
            var response = _client.Post(
                TestData.Urls.RefreshApi,
                new RefreshRequest { RefreshToken = "invalid.token.here" });

            Assert.That((int)response.StatusCode, Is.EqualTo(401),
                $"Expected 401 for bad refresh token, got {(int)response.StatusCode}");
        }

        [Test]
        [Description("Empty refresh token body should return 400")]
        public void TC_API_011_Refresh_EmptyToken_Returns400()
        {
            var response = _client.Post(
                TestData.Urls.RefreshApi,
                new RefreshRequest { RefreshToken = "" });

            Assert.That((int)response.StatusCode,
                Is.EqualTo(400).Or.EqualTo(401),
                $"Expected 400 or 401, got {(int)response.StatusCode}");
        }

        // =========================================================================
        // POST /api/auth/logout
        // =========================================================================

        [Test]
        [Description("Valid logout with Bearer token should return 200 or 204")]
        public void TC_API_012_Logout_ValidToken_Returns200Or204()
        {
            if (string.IsNullOrEmpty(_validAccessToken))
                Assert.Ignore("Skipped: no valid access token from pre-login setup");

            using var authClient = new ApiClient(_validAccessToken);
            var response = authClient.Post(
                TestData.Urls.LogoutApi,
                new LogoutRequest { RefreshToken = _validRefreshToken ?? "" });

            Assert.That((int)response.StatusCode,
                Is.EqualTo(200).Or.EqualTo(204),
                $"Expected 200 or 204 for valid logout, got {(int)response.StatusCode}");
        }

        [Test]
        [Description("Logout without Authorization header should return 401")]
        public void TC_API_013_Logout_NoToken_Returns401()
        {
            var response = _client.Post(
                TestData.Urls.LogoutApi,
                new LogoutRequest { RefreshToken = "some-token" });

            Assert.That((int)response.StatusCode, Is.EqualTo(401),
                $"Expected 401 when no auth header, got {(int)response.StatusCode}");
        }

        // =========================================================================
        // GET /api/auth/userinfo
        // =========================================================================

        [Test]
        [Description("Authenticated GET /userinfo should return user email and id")]
        public void TC_API_014_UserInfo_WithValidToken_Returns200WithUserData()
        {
            if (string.IsNullOrEmpty(_validAccessToken))
                Assert.Ignore("Skipped: no valid access token from pre-login setup");

            using var authClient = new ApiClient(_validAccessToken);
            var response = authClient.Get<UserInfoResponse>(TestData.Urls.UserInfoApi);

            Assert.That((int)response.StatusCode, Is.EqualTo(200),
                $"Expected 200, got {(int)response.StatusCode}. Body: {response.Content}");

            var data = response.Data;
            Assert.That(data,        Is.Not.Null);
            Assert.That(data!.Email, Is.Not.Null.And.Not.Empty, "User email should be present");
            Assert.That(data.Id,     Is.Not.Null.And.Not.Empty, "User id should be present");
        }

        [Test]
        [Description("GET /userinfo without token should return 401")]
        public void TC_API_015_UserInfo_NoToken_Returns401()
        {
            var response = _client.Get(TestData.Urls.UserInfoApi);

            Assert.That((int)response.StatusCode, Is.EqualTo(401),
                $"Expected 401 for unauthenticated request, got {(int)response.StatusCode}");
        }

        [Test]
        [Description("GET /userinfo with malformed Bearer token should return 401")]
        public void TC_API_016_UserInfo_MalformedToken_Returns401()
        {
            using var badClient = new ApiClient("this.is.not.a.real.jwt");
            var response = badClient.Get(TestData.Urls.UserInfoApi);

            Assert.That((int)response.StatusCode, Is.EqualTo(401),
                $"Expected 401 for malformed token, got {(int)response.StatusCode}");
        }

        // =========================================================================
        // Response Schema Validation
        // =========================================================================

        [Test]
        [Description("Login 200 response schema must contain all required fields")]
        public void TC_API_017_Login_ResponseSchema_HasRequiredFields()
        {
            var response = _client.Post(
                TestData.Urls.LoginApi,
                new LoginRequest
                {
                    Email    = TestData.Users.ValidUser.Email,
                    Password = TestData.Users.ValidUser.Password
                });

            Assert.That((int)response.StatusCode, Is.EqualTo(200));

            var json = JsonConvert.DeserializeObject<Dictionary<string, object>>(
                response.Content ?? "{}");

            Assert.That(json, Is.Not.Null);
            Assert.That(json!.ContainsKey("accessToken"),  Is.True, "Schema: missing 'accessToken'");
            Assert.That(json.ContainsKey("refreshToken"),  Is.True, "Schema: missing 'refreshToken'");
            Assert.That(json.ContainsKey("tokenType"),     Is.True, "Schema: missing 'tokenType'");
            Assert.That(json.ContainsKey("expiresIn"),     Is.True, "Schema: missing 'expiresIn'");
        }

        [Test]
        [Description("Error response schema must contain a message field")]
        public void TC_API_018_ErrorResponse_Schema_HasMessageField()
        {
            var response = _client.Post(
                TestData.Urls.LoginApi,
                new LoginRequest { Email = "bad@test.com", Password = "WrongPass" });

            Assert.That((int)response.StatusCode, Is.EqualTo(401));

            var json = JsonConvert.DeserializeObject<Dictionary<string, object>>(
                response.Content ?? "{}");

            Assert.That(json, Is.Not.Null, "Error body should be valid JSON");
            var hasMessage = json!.ContainsKey("message") || json.ContainsKey("error");
            Assert.That(hasMessage, Is.True,
                $"Error response should contain 'message' or 'error' field. Body: {response.Content}");
        }

        // =========================================================================
        // Content-Type / Headers
        // =========================================================================

        [Test]
        [Description("Login endpoint should return Content-Type: application/json")]
        public void TC_API_019_Login_ResponseHeader_ContentTypeIsJson()
        {
            var response = _client.Post(
                TestData.Urls.LoginApi,
                new LoginRequest
                {
                    Email    = TestData.Users.ValidUser.Email,
                    Password = TestData.Users.ValidUser.Password
                });

            var contentType = response.ContentType ?? "";
            Assert.That(contentType, Does.Contain("application/json").IgnoreCase,
                $"Expected Content-Type: application/json, got: {contentType}");
        }

        // =========================================================================
        // GET /api/auth/token (if separate from login)
        // =========================================================================

        [Test]
        [Description("Token endpoint without credentials should return 400 or 401")]
        public void TC_API_020_Token_NoCredentials_Returns4xx()
        {
            var response = _client.Get(TestData.Urls.TokenApi);

            Assert.That((int)response.StatusCode,
                Is.EqualTo(400).Or.EqualTo(401).Or.EqualTo(405),
                $"Expected 4xx, got {(int)response.StatusCode}");
        }
    }
}
