# Zywave Login Automation — QA Assignment

**Problem Statement:** Automation for Login UI and API  
**Tech:** C# · .NET 7 · NUnit · Selenium WebDriver · RestSharp

---

## Project Structure

```
ZywaveLoginAutomation/
├── Common/
│   ├── BaseTest.cs        # WebDriver setup/teardown + ExtentReports
│   ├── TestData.cs        # Credentials, URLs, timeouts, expected messages
│   └── WaitHelper.cs      # Explicit wait utilities
├── UI/
│   ├── Pages/
│   │   └── LoginPage.cs   # Page Object Model for login screen
│   └── Tests/
│       └── LoginUITests.cs  # 17 UI test cases
├── API/
│   ├── ApiClient.cs       # RestSharp wrapper
│   ├── Models/
│   │   └── ApiModels.cs   # Request/Response DTOs
│   └── Tests/
│       └── AuthApiTests.cs  # 20 API test cases
├── NUnit.runsettings
└── ZywaveLoginAutomation.csproj
```

---

## Prerequisites

| Tool | Version |
|------|---------|
| .NET SDK | 7.0+ |
| Google Chrome | Latest |
| ChromeDriver | Auto-managed by WebDriverManager |

Install .NET 7: https://dotnet.microsoft.com/download/dotnet/7.0

---

## Setup

```bash
# 1. Restore NuGet packages
dotnet restore

# 2. Build
dotnet build
```

---

## Running Tests

```bash
# Run ALL tests
dotnet test --settings NUnit.runsettings

# Run only UI tests
dotnet test --filter Category=UI --settings NUnit.runsettings

# Run only API tests
dotnet test --filter Category=API --settings NUnit.runsettings

# Run only security tests
dotnet test --filter Category=Security --settings NUnit.runsettings

# Run only negative scenarios
dotnet test --filter Category=NegativeScenarios --settings NUnit.runsettings

# Run with verbose console output
dotnet test --settings NUnit.runsettings --logger "console;verbosity=detailed"
```

---

## Test Reports

After running, two HTML reports are generated:

| Report | Location |
|--------|----------|
| UI Tests | `bin/Debug/net7.0/Reports/TestReport.html` |
| API Tests | `bin/Debug/net7.0/Reports/ApiTestReport.html` |
| NUnit XML | `bin/Debug/net7.0/Reports/TestResults.xml` |

Open the HTML files in any browser.

---

## Configuration

All configuration is in `Common/TestData.cs`:

```csharp
// Update with real credentials provided by Zywave
public static readonly (string Email, string Password) ValidUser =
    ("testuser@zywave.com", "Test@1234");

// Update base URL if app runs on a different port
public const string BaseUrl = "http://localhost:5000";
```

---

## Test Coverage Summary

### UI Tests (17 cases)
| ID | Scenario | Type |
|----|----------|------|
| TC_UI_001 | Valid login → redirect | Happy Path |
| TC_UI_002 | Empty fields → required error | Validation |
| TC_UI_003 | Empty password → error | Validation |
| TC_UI_004 | Empty email → error | Validation |
| TC_UI_005 | Invalid email format → format error | Validation |
| TC_UI_006 | Wrong password → invalid credentials | Negative |
| TC_UI_007 | Wrong email → generic error (no user enumeration) | Security |
| TC_UI_008 | Locked account → locked message | Negative |
| TC_UI_009 | Password field masked by default | UI Behaviour |
| TC_UI_010 | Password toggle → reveals text | UI Behaviour |
| TC_UI_011 | Toggle twice → re-masks | UI Behaviour |
| TC_UI_012 | SQL injection → blocked | Security |
| TC_UI_013 | Page loads correctly | Smoke |
| TC_UI_014 | Forgot password link present | UI Elements |
| TC_UI_015 | Login button enabled by default | UI Elements |
| TC_UI_016 | Overly long input → no crash | Edge Case |
| TC_UI_017 | Expired password → error | Negative |

### API Tests (20 cases)
| ID | Endpoint | Scenario | Expected |
|----|----------|----------|----------|
| TC_API_001 | POST /login | Valid credentials | 200 + tokens |
| TC_API_002 | POST /login | Response is JSON | valid JSON |
| TC_API_003 | POST /login | Wrong password | 401 |
| TC_API_004 | POST /login | Non-existent email | 401 (not 404) |
| TC_API_005 | POST /login | Empty credentials | 400/422 |
| TC_API_006 | POST /login | Malformed JSON | 400 |
| TC_API_007 | POST /login | Locked account | 401/423 |
| TC_API_008 | POST /login | SQL injection | Not 200 |
| TC_API_009 | POST /refresh | Valid refresh token | 200 + new token |
| TC_API_010 | POST /refresh | Invalid token | 401 |
| TC_API_011 | POST /refresh | Empty token | 400/401 |
| TC_API_012 | POST /logout | Valid auth | 200/204 |
| TC_API_013 | POST /logout | No auth header | 401 |
| TC_API_014 | GET /userinfo | Valid token | 200 + user data |
| TC_API_015 | GET /userinfo | No token | 401 |
| TC_API_016 | GET /userinfo | Malformed token | 401 |
| TC_API_017 | POST /login | Response schema check | all fields present |
| TC_API_018 | POST /login | Error schema check | message/error field |
| TC_API_019 | POST /login | Content-Type header | application/json |
| TC_API_020 | GET /token | No credentials | 4xx |

---

## Locator Update Guide

When you get access to the live app, inspect the DOM and update locators in `LoginPage.cs`:

```csharp
// Current (generic fallback selectors)
private readonly By _emailField = By.CssSelector("input[type='email'], input[name='email']");

// Update to specific selectors from the actual app, e.g.:
private readonly By _emailField = By.Id("loginEmail");
private readonly By _passwordField = By.Name("password");
private readonly By _loginButton = By.CssSelector("button.btn-primary");
```

---

## Java → C# Quick Reference

| Java (your stack) | C# equivalent |
|---|---|
| `@Test` | `[Test]` |
| `@BeforeMethod` | `[SetUp]` |
| `@AfterMethod` | `[TearDown]` |
| `@BeforeClass` | `[OneTimeSetUp]` |
| `Assert.assertEquals` | `Assert.That(x, Is.EqualTo(y))` |
| `RestAssured.given()` | `new ApiClient()` |
| `response.statusCode()` | `(int)response.StatusCode` |
| `response.jsonPath().get("field")` | `response.Data?.Field` |
| `@DataProvider` | `[TestCaseSource]` |
