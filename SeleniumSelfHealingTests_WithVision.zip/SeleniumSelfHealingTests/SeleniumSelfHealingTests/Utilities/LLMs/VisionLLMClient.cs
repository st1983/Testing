using System.Text;
using System.Text.Json;
using SeleniumSelfHealingTests.Utilities.Models;

namespace SeleniumSelfHealingTests.Utilities.LLMs;

public class VisionLLMClient
{
    private readonly HttpClient _httpClient;

    private readonly LLMConfig _llmConfig;

    public VisionLLMClient()
    {
        _httpClient = new HttpClient();
        _llmConfig = ReadJsonFile();
    }

    private async Task<string> CallLocalVisionLLMAsync(string prompt, string base64Image1, string base64Image2)
    {
        var requestBody = new
        {
            model = _llmConfig.Model,
            prompt = prompt,
            images = new [] {base64Image1, base64Image2},
            stream = false,
            options = new { temperature = _llmConfig.Temperature }
        };

        var json = JsonSerializer.Serialize(requestBody);
        var content = new StringContent(json, Encoding.UTF8, "application/json");

        var response = await _httpClient.PostAsync($"{_llmConfig.BaseUrl}/api/generate", content);

        response.EnsureSuccessStatusCode();

        var responseText = await response.Content.ReadAsStringAsync();
        var jsonResponse = JsonSerializer.Deserialize<JsonElement>(responseText);

        return jsonResponse.GetProperty("response").GetString() ?? string.Empty;

    }

    private async Task<string> CallOpenAIVisionAsync(string prompt, string base64Image1, string base64Image2)
    {
        var requestBody = new
        {
            model = _llmConfig.Model,
            messages = new[]
            {
                new
                {
                    role = "user",
                    content = new object[]
                    {
                        new { type = "text", text = prompt },
                        new
                        {
                            type = "image_url",
                            image_url = new
                            {
                                url = $"data:image/png;base64,{base64Image1}"
                            }
                        },
                        new
                        {
                            type = "image_url",
                            image_url = new
                            {
                                url = $"data:image/png;base64,{base64Image2}"
                            }
                        }
                    }
                }
            },
            max_tokens = _llmConfig.MaxTokens
        };

        var json = JsonSerializer.Serialize(requestBody);
        var content = new StringContent(json, Encoding.UTF8, "application/json");

        //Add the authorization header with the openai API Key
        _httpClient.DefaultRequestHeaders.Add("Authorization", $"Bearer {_llmConfig.ApiKey}");

        var response = await _httpClient.PostAsync($"{_llmConfig.BaseUrl}/v1/chat/completions", content);

        response.EnsureSuccessStatusCode();

        var responseText = await response.Content.ReadAsStringAsync();
        var jsonResponse = JsonSerializer.Deserialize<JsonElement>(responseText);

        return jsonResponse.GetProperty("choices")
            .EnumerateArray()
            .First()
            .GetProperty("message")
            .GetProperty("content")
            .GetString() ?? string.Empty;

    }

    public async Task<string> GetVisionCompletionAsync(string prompt, string base64Image1, string base64Image2)
    {
        return _llmConfig.Provider.ToLower() switch
        {
            "openai" => await CallOpenAIVisionAsync(prompt, base64Image1, base64Image2),
            "local" => await CallLocalVisionLLMAsync(prompt, base64Image1, base64Image2),
            _ => throw new NotSupportedException($"Provider {_llmConfig.Provider} is not supported")
        };
    }


    private LLMConfig ReadJsonFile()
    {
        var jsonFilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "appsetting.json");
        string jsonData = File.ReadAllText(jsonFilePath);
        return JsonSerializer.Deserialize<LLMConfig>(jsonData);
    }
}