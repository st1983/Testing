using System.Text.Json;
using SeleniumSelfHealingTests.Utilities.Models;

namespace SeleniumSelfHealingTests.Utilities.LLMs;


//Store the locators in the Cache
//Get the locators from the cache
//Load the locator from the file (json)
public class LocatorCache
{
    private readonly string _cacheFilePath;
    private List<HealedLocator> _cache;

    public LocatorCache()
    {
        _cacheFilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "healed-locator.json");
        _cache = LoadCacheFromFile();
    }


    public bool TryGetHealedLocator(string originalLocator, out HealedLocator? healedLocator)
    {
        healedLocator = _cache.FirstOrDefault(l => l.OriginalLocator == originalLocator);
        return healedLocator != null;
    }
    

    public void SaveHealedLocator(string originalLocator, string workingLocatorType, string workingLocatorValue)
    {
        var existing = _cache.FirstOrDefault(l => l.OriginalLocator == originalLocator);

        //Updation
        if (existing != null)
        {
            existing.WorkingLocatorType = workingLocatorType;
            existing.WorkingLocatorValue = workingLocatorValue;
            existing.HealedAt = DateTime.Now;
        }
        else
        {
            _cache.Add(new HealedLocator
            {
                OriginalLocator = originalLocator,
                WorkingLocatorType = workingLocatorType,
                WorkingLocatorValue = workingLocatorValue,
                HealedAt = DateTime.Now
            });
        }
        
        //Save to a file
        SaveCacheToFile();
    }

    private void SaveCacheToFile()
    {

        try
        {
            var json = JsonSerializer.Serialize(_cache, new JsonSerializerOptions
            {
                WriteIndented = true
            });
            
            File.WriteAllText(_cacheFilePath, json);
            Console.WriteLine("Save the Cache to the file path");
        }
        catch (Exception ex)
        {
            Console.WriteLine("File Saving Failed " + ex);
        }
    }

    private List<HealedLocator> LoadCacheFromFile()
    {
        try
        {
            if (File.Exists(_cacheFilePath))
            {
                var json = File.ReadAllText(_cacheFilePath);
                var cache = JsonSerializer.Deserialize<List<HealedLocator>>(json);
                return cache ?? new List<HealedLocator>();
            }

        }
        catch (Exception ex)
        {
            Console.WriteLine("File Loading Failed " + ex);
        }

        return new List<HealedLocator>();
    }
}