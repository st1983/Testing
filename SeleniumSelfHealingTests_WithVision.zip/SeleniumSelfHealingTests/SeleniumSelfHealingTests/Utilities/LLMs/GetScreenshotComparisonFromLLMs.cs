using System.Text.Json;
using SeleniumSelfHealingTests.Utilities.Models;

namespace SeleniumSelfHealingTests.Utilities.LLMs;

public static class GetScreenshotComparisonFromLLMs
{
    public static async Task<VisionComparisonResult> CompareScreenshotsAsync(VisionLLMClient visionLlmClient,
        string base64Image1, string base64Image2)
    {
        
        var prompt = @"You are comparing TWO screenshots to determine if they are IDENTICAL or DIFFERENT.

                    IMAGE 1: The baseline/expected screenshot
                    IMAGE 2: The current/actual screenshot

                    IMPORTANT INSTRUCTIONS:
                    - First, carefully examine both images to see if they are EXACTLY THE SAME
                    - Be VERY CONSERVATIVE - only report differences if you can CLEARLY see them
                    - Do NOT invent or hallucinate differences that are not actually visible
                    - If the images appear identical or nearly identical, set areEqual to true and similarityScore to 95-100
                    - Only set areEqual to false if you can CLEARLY identify actual, visible differences

                    Provide your analysis in this EXACT JSON format:
                    {
                        ""AreEqual"": true/false,
                        ""SimilarityScore"": 0-100,
                        ""Differences"": ""specific description of actual visible differences, or 'No significant differences detected' if images are the same"",
                        ""Analysis"": ""brief analysis"",
                        ""IdentifiedIssues"": [""only list issues you can CLEARLY see""]
                    }

                    If the images look identical or nearly identical:
                    - Set areEqual to true
                    - Set similarityScore to 95-100
                    - Set differences to ""No significant differences detected""
                    - Set identifiedIssues to empty array []

                    Only report differences you can ACTUALLY SEE. Be honest and conservative.
                    Provide ONLY the JSON response, no additional text.
                ";

        var response = await visionLlmClient.GetVisionCompletionAsync(prompt, base64Image1, base64Image2);

        var cleanedResponse = response.Trim();
        
        //Remove ```json 
        if (cleanedResponse.StartsWith("```json", StringComparison.OrdinalIgnoreCase))
            cleanedResponse = cleanedResponse.Substring(7);
        if (cleanedResponse.StartsWith("```"))
            cleanedResponse = cleanedResponse.Substring(3);
        if (cleanedResponse.EndsWith("```"))
            cleanedResponse = cleanedResponse.Substring(0, cleanedResponse.Length - 3);

        cleanedResponse = cleanedResponse.Trim();

        var result = JsonSerializer.Deserialize<VisionComparisonResult>(cleanedResponse);

        return result;
    } 
}