namespace SeleniumSelfHealingTests.Utilities.Models;

public class HealedLocator
{
    public string OriginalLocator { get; set; } = string.Empty;
    public string WorkingLocatorType { get; set; } = string.Empty;
    public string WorkingLocatorValue { get; set; } = string.Empty;
    public DateTime HealedAt { get; set; } = DateTime.Now;
}