namespace SeleniumSelfHealingTests.Utilities.Models;

public class VisionComparisonResult
{
    public bool AreEqual { get; set; }
    public double SimilarityScore { get; set; }
    public string Differences { get; set; } = string.Empty;
    public string Analysis { get; set; } = string.Empty;
    public List<string> IdentifiedIssues { get; set; } = new();
    public string RawResponse { get; set; } = string.Empty;
}