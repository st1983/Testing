using Microsoft.Playwright;
using PlaywrightSelfHealingTests.Utilities.LLMs;

namespace PlaywrightSelfHealingTests.Utilities.Extensions;

public static class PlaywrightExtensions
{
    public static async Task<ILocator> AiFindElementAsync(this IPage page, string selector)
    {
        SelfHealingLocators selfHealingLocators = new SelfHealingLocators(page, selector);
        return await selfHealingLocators.FindElementAsync();
    }


    public static async Task ClickAsync(this Task<ILocator> locator)
    {
        var element = await locator;
        await element.ClickAsync();
    }
    
    public static async Task FillAsync(this Task<ILocator> locator, string text)
    {
        var element = await locator;
        await element.FillAsync(text);
    }
}