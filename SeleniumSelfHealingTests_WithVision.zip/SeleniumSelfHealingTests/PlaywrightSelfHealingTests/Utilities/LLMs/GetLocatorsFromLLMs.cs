using System.Text.Json;
using PlaywrightSelfHealingTests.Models;

namespace PlaywrightSelfHealingTests.Utilities.LLMs;

public static class GetLocatorsFromLLMs
{
    public static async Task<LocatorSuggestions?> GetHealedLocator(LLMClient client, string pageSource, string locatorType, string originalLocator)
    {
        var prompt = $@"

                    The Web element with locatorType: {locatorType} and it locator {originalLocator} cannot be found the page.
                    Based on the current page source, suggest alternative locators that might work.
        
                    IMPORTANT: Return ONLY a valid JSON object with these keys:
                    - id: The id attribute value (if available)
                    - name: The name attribute value (if available)
                    - xpath: XPath expression to locate the element
                    - cssSelector: CSS selector to locate the element
                    - className: The class attribute value (if available)
                    - linkText: The exact link text (if it's a link)
                    - role: ARIA role attribute (Playwright role selector, e.g., 'button', 'textbox', 'link')
                    - testId: data-testid or data-test attribute value (if available)
                    - placeholder: placeholder attribute value (for input fields)
                    - text: Visible text content of the element

                    Format as a proper JSON object with double quotes. Do not include any text before or after the JSON object.
                    Do not include explanations, comments, or markdown code blocks - just return the raw JSON object.

                    Example format:
                    {{
                      ""id"": ""submit-btn"",
                      ""name"": ""submitButton"",
                      ""xpath"": ""//button[@type='submit']"",
                      ""cssSelector"": ""button.submit-btn"",
                      ""className"": ""submit-btn primary"",
                      ""linkText"": """",
                      ""role"": ""button"",
                      ""testId"": ""submit-button"",
                      ""placeholder"": """",
                      ""text"": ""Submit""
                    }}
                    Page content (truncated):  {pageSource}
            ";

        var response = await client.GetCompletionAsync(prompt);
        
        return JsonSerializer.Deserialize<LocatorSuggestions>(response) ?? null;
    }
}