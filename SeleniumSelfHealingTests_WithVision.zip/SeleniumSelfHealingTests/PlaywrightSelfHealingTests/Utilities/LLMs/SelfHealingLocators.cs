using Microsoft.Playwright;

namespace PlaywrightSelfHealingTests.Utilities.LLMs;

public class SelfHealingLocators
{
    private readonly IPage _page;
    private string _currentStrategy;
    private readonly Dictionary<string, string> _locatorStrategies;

    public SelfHealingLocators(IPage page, string primaryLocator)
    {
       _page = page;
        _currentStrategy = primaryLocator;
        _locatorStrategies = new Dictionary<string, string> { { "primary", primaryLocator } };
    }

    public async Task<ILocator> FindElementAsync(int retryAttempts = 2)
    {
        //Step 1: Try finding the element using Current Strategy
        var element = await TryFindWithCurrentStrategyAsync();
        if (element != null) return element;
        
        //Step 2 - Find the alternative Strategy 
        element = await TryAlternativeStrategiesAsync();
        if (element != null) return element;
        
        //Step 3 - AI Based AutoHealing approach
        if (retryAttempts > 0)
        {
            await HealUsingAI();
            return await FindElementAsync(retryAttempts -1);
        }

        throw new PlaywrightException($"Failed to locate the element after all healing attempts: {retryAttempts}");
    }


    private async Task<ILocator?> TryFindWithCurrentStrategyAsync()
    {
        try
        {
            var locator = _page.Locator(_currentStrategy);

            await locator.WaitForAsync(new LocatorWaitForOptions
            {
                State = WaitForSelectorState.Attached,
                Timeout = 3000
            });

            return locator;
        }
        catch (TimeoutException)
        {
            return null;
        }
    }

    private async Task<ILocator?> TryAlternativeStrategiesAsync()
    {
        if (_locatorStrategies.Count <= 1) return null;

        foreach (var (strategyName, strategy) in _locatorStrategies)
        {
            if(strategy.Equals(_currentStrategy)) continue;

            try
            {
                var locator = _page.Locator(strategy);

                await locator.WaitForAsync(new LocatorWaitForOptions
                {
                    State = WaitForSelectorState.Attached,
                    Timeout = 2000
                });
                _currentStrategy = strategy; //Update to successful strategy
                return locator;
            }
            catch (TimeoutException)
            {
                return null;
            }
        }
        return null;
    }

    private async Task HealUsingAI()
    {
        try
        {
            var (locatorType, locatorValue) = ParseLocatorStrategy(_currentStrategy);

            var pageSource = await _page.ContentAsync();

            LLMClient client = new LLMClient();
            var suggestedLocators =
                await GetLocatorsFromLLMs.GetHealedLocator(client, pageSource, locatorType, locatorValue);

            int addedCount = 0;
            addedCount += TryCreateLocatorStrategy("id", suggestedLocators.id);
            addedCount += TryCreateLocatorStrategy("xpath", suggestedLocators.xpath);
            addedCount += TryCreateLocatorStrategy("css", suggestedLocators.cssSelector);
            addedCount += TryCreateLocatorStrategy("name", suggestedLocators.name);
            addedCount += TryCreateLocatorStrategy("class", suggestedLocators.className);
            addedCount += TryCreateLocatorStrategy("linkText", suggestedLocators.linkText);

            Console.WriteLine(
                $"AI healing completed with total added locators are {addedCount} as alternative locators");
        }
        catch (Exception ex)
        {
            Console.WriteLine("AI healing failed");
        }
    }


    private int TryCreateLocatorStrategy(string locatorType, string locatorValue)
    {
        if (string.IsNullOrWhiteSpace(locatorValue))
            return 0;

        try
        {
            string playwrightSelector = locatorType.ToLowerInvariant() switch
            {
                "id" => $"#{locatorValue}",
                "name" => $"[name='{locatorValue}']",
                "class" => $".{locatorValue.Split(' ')[0]}",
                "css" => locatorValue,
                "xpath" => locatorValue,
                "text" => $"text={locatorValue}",
                "role" => $"role={locatorValue}",
                "testid" => $"[data-testid='{locatorValue}']",
                "placeholder" => $"[placeholder='{locatorValue}']",
                _ => null
            };

            if (playwrightSelector != null)
            {
                _locatorStrategies[locatorType] = playwrightSelector; 
                return 1;
            }

            return 0;
        }
        catch
        {
            // Ignore invalid locators
            return 0;
        }
    }


    private (string type, string value) ParseLocatorStrategy(string selector)
    {
        if (selector.StartsWith("#"))
            return ("id", selector.Substring(1));
        if (selector.StartsWith("."))
            return ("class", selector.Substring(1));
        if (selector.StartsWith("//"))
            return ("xpath", selector.Substring(1));
        if (selector.StartsWith("text="))
            return ("text", selector.Substring(5));
        if (selector.StartsWith("role="))
            return ("role", selector.Substring(5));
        if (selector.StartsWith("[data-testid="))
            return ("testId", ExtractAttributeValue(selector, "data-testid"));
        if (selector.StartsWith("[placeholder"))
            return ("placeholder", ExtractAttributeValue(selector, "placeholder"));
        if (selector.StartsWith("[name"))
            return ("name", ExtractAttributeValue(selector, "name"));
        
        return ("css", selector);
    }
    
    private string ExtractAttributeValue(string selector, string attribute)
    {
        var startIndex = selector.IndexOf($"{attribute}=");
        if (startIndex == -1) return selector;

        startIndex += attribute.Length + 2; // Skip attribute= and quote
        var endIndex = selector.IndexOf(selector[startIndex - 1], startIndex);
        
        return endIndex > startIndex 
            ? selector.Substring(startIndex, endIndex - startIndex) 
            : selector;
    }
    
}