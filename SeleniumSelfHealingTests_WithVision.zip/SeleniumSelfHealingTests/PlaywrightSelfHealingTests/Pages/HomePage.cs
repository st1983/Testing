using Microsoft.Playwright;
using PlaywrightSelfHealingTests.Utilities.Extensions;

namespace PlaywrightSelfHealingTests.Pages;

public class HomePage
{
    private readonly IPage _page;
    
    public HomePage(IPage page)
    {
        _page = page;
    }
    
    private Task<ILocator> LoginLink => _page.AiFindElementAsync("text=Login");
    private Task<ILocator> EmployeeDetailsLink => _page.AiFindElementAsync("text=Employee Details");
    private Task<ILocator> ManageUsersLink => _page.AiFindElementAsync("text=Manage Users");
    private Task<ILocator> LogoffLink => _page.AiFindElementAsync("text=Log off");
    
    // One-step click operations using the element properties and new extension methods
    public async Task ClickLogin() => await LoginLink.ClickAsync();
    
    public async Task ClickEmployeeDetails() => await EmployeeDetailsLink.ClickAsync();
    
    public async Task ClickManageUsers() => await ManageUsersLink.ClickAsync();
    
    public async Task ClickLogoff() => await LogoffLink.ClickAsync();
}
