using Microsoft.Playwright;
using PlaywrightSelfHealingTests.Utilities.Extensions;

namespace PlaywrightSelfHealingTests.Pages
{
    public class LoginPage
    {
        private readonly IPage _page;
        
        public LoginPage(IPage page) => _page = page;

        private Task<ILocator> UsernameField => _page.AiFindElementAsync("#UserNamessss");
        private Task<ILocator> PasswordField => _page.AiFindElementAsync("#Passwordsssss");
        private Task<ILocator> LoginButton => _page.AiFindElementAsync("input[type='submitssdds']");
    
        public async Task Login(string userName, string password)
        {
            await UsernameField.FillAsync(userName);
            await PasswordField.FillAsync(password);
            await LoginButton.ClickAsync();
        }
  
    }
}
