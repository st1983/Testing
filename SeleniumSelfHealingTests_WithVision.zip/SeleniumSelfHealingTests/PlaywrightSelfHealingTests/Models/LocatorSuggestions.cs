namespace PlaywrightSelfHealingTests.Models;

public class LocatorSuggestions
{
        public string id { get; set; }
        public string name { get; set; }
        public string xpath { get; set; }
        public string cssSelector { get; set; }
        public string className { get; set; }
        public string linkText { get; set; }
        public string role { get; set; } = string.Empty;
        public string testId { get; set; } = string.Empty;
        public string placeholder { get; set; } = string.Empty; 
        public string text { get; set; } = string.Empty;
        
}