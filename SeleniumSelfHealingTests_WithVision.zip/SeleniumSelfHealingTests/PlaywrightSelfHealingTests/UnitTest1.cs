﻿using Microsoft.Playwright;
using PlaywrightSelfHealingTests.Pages;

namespace PlaywrightSelfHealingTests;

public class UnitTest1
{
    [Fact]
    public async Task Test1()
    {
        using var playwright = await Playwright.CreateAsync();
        
        await using var browser = await playwright.Chromium.LaunchAsync(new BrowserTypeLaunchOptions
        {
            Headless = false
        });

        var context = await browser.NewContextAsync();
        var page = await context.NewPageAsync();

        await page.GotoAsync("http://eaapp.somee.com");
        
        // Use enhanced page objects with self-healing elements
        var homePage = new HomePage(page);
        await homePage.ClickLogin();
            
        var loginPage = new LoginPage(page);
        await loginPage.Login("admin", "password");
            
        //Click Employee Details
        await homePage.ClickEmployeeDetails();

        await homePage.ClickManageUsers();

        await homePage.ClickLogoff();
    }
}