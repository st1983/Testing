using OpenQA.Selenium;

namespace SeleniumSelfHealingTests.Pages;

public class HomePage
{
    private readonly IWebDriver _driver;
    private IWebElement LoginLink => _driver.FindElement(By.LinkText("Login"));
    private IWebElement EmployeeDetailsLink => _driver.FindElement(By.LinkText("Employee Details"));
    private IWebElement ManageUsersLink => _driver.FindElement(By.LinkText("Manage Users"));
    private IWebElement LogoffLink => _driver.FindElement(By.LinkText("Log off"));
    
    public HomePage(IWebDriver driver)
    {
        _driver = driver;
    }
    
    // One-step click operations using the element properties and new extension methods
    public void ClickLogin() => LoginLink.Click();
    
    public void ClickEmployeeDetails() => EmployeeDetailsLink.Click();
    
    public void ClickManageUsers() => ManageUsersLink.Click();
    
    public void ClickLogoff() => LogoffLink.Click();
}
