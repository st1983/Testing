using OpenQA.Selenium;

namespace SeleniumSelfHealingTests.Pages;

public class LoginPage
{
    public LoginPage(IWebDriver driver)
    {
        _driver = driver;
    }
    
    private readonly IWebDriver _driver;
    private IWebElement UsernameField => _driver.FindElement(By.Id("UserName"));
    private IWebElement PasswordField => _driver.FindElement(By.Id("Password"));
    private IWebElement LoginButton => _driver.FindElement(By.CssSelector("input[type='submit']"));
    
    public void Login(string userName, string password)
    {
       UsernameField.SendKeys(userName);
       PasswordField.SendKeys(password);
       LoginButton.Click();
    }
  
}
