using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using SeleniumSelfHealingTests.Pages;
using SeleniumSelfHealingTests.Utilities;

namespace SeleniumSelfHealingTests.Tests;

public class EnhancedTests
{
    [Fact]
    public void TraditionalTest()
    {
        // Setup driver with some basic options
        var options = new ChromeOptions();
        options.AddArgument("--start-maximized");
        
        IWebDriver driver = new ChromeDriver(options);
        try
        {
            driver.Navigate().GoToUrl("http://eaapp.somee.com");
            
            // Use enhanced page objects with self-healing elements
            var homePage = new HomePage(driver);
            homePage.ClickLogin();
            
            var loginPage = new LoginPage(driver);
            loginPage.Login("admin", "password");
            
            //Click Employee Details
            homePage.ClickEmployeeDetails();

            homePage.ClickManageUsers();

            homePage.ClickLogoff();

        }
        finally
        {
            // Clean up
            driver.Quit();
        }
    }

    [Fact]
    public async Task CallingLLMClient()
    {

        // Setup driver with some basic options
        var options = new ChromeOptions();
        options.AddArgument("--start-maximized");
        
        IWebDriver driver = new ChromeDriver(options);
        driver.Navigate().GoToUrl("http://eaapp.somee.com");

        var pageSource = driver.PageSource;
        var locator = By.LinkText("Login");

        var strategyString = locator.ToString();
        int separatorIndex = strategyString.IndexOf(":");

        string locatorType = strategyString.Substring(0, separatorIndex);
        string locatorValue = strategyString.Substring(separatorIndex + 1).Trim();
        
        LLMClient client = new LLMClient();
        var prompt = GetHealedLocator(pageSource, locatorType, locatorValue);
        var result =
            await client.GetCompletionAsync(prompt);
        Console.Write(result);
    }


    public string GetHealedLocator(string pageSource, string locatorType, string orginalLocator)
    {

        var prompt = $@"

                    The Web element with locatorType: {locatorType} and it locator {orginalLocator} cannot be found the page.
                    Based on the current page source, suggest alternative locators that might work.
        
                       IMPORTANT: Return ONLY a valid JSON object with these keys: id, name, xpath, cssSelector, className, linkText.
                        - id
                        - name  
                        - xpath
                        - cssSelector
                        - className
                        - linkText

                        Format as a proper JSON with double quotes. Do not include any text before or after the JSON object.
                        Do not include explanations or comments, just return the JSON object.

                        Page source (truncated): {pageSource}
            ";

        return prompt;
    }
}
